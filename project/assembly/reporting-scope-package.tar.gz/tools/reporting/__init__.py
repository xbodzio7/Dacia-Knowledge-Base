"""Shared validation for explicit configuration reporting scopes."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

EXPLICIT_SUBSET = "explicit_subset"


class ConfigurationReportingScopeError(ValueError):
    """Raised when a reporting scope is malformed or references invalid rows."""


@dataclass(frozen=True)
class ConfigurationReportingScope:
    """Resolved declarative configuration scope."""

    mode: str
    status: str
    configuration_sources: dict[str, str]
    selected_rows: dict[str, Mapping[str, str]]
    status_rows: dict[str, Mapping[str, str]]
    excluded_codes: tuple[str, ...]

    @property
    def selected_codes(self) -> tuple[str, ...]:
        return tuple(sorted(self.configuration_sources))

    def metadata(self) -> dict[str, Any]:
        """Return stable disclosure fields shared by generated reports."""

        return {
            "configuration_scope": self.mode,
            "reporting_configurations": len(self.configuration_sources),
            "repository_status_configurations": len(self.status_rows),
            "excluded_status_configurations": len(self.excluded_codes),
            "excluded_configuration_codes": list(self.excluded_codes),
        }


def resolve_configuration_reporting_scope(
    spec: Mapping[str, Any],
    configurations: Sequence[Mapping[str, str]],
) -> ConfigurationReportingScope:
    """Resolve one explicit subset of repository configurations.

    The selected rows must exist and have the declared status. Other rows with
    the same status are intentionally allowed to remain outside the reporting
    denominator and are disclosed through ``excluded_codes``.
    """

    mode = spec.get("configuration_scope", EXPLICIT_SUBSET)
    if mode != EXPLICIT_SUBSET:
        raise ConfigurationReportingScopeError(
            "configuration_scope must be 'explicit_subset'"
        )

    status = spec.get("configuration_status")
    if not isinstance(status, str) or not status:
        raise ConfigurationReportingScopeError(
            "configuration_status must be a non-empty string"
        )

    status_rows: dict[str, Mapping[str, str]] = {}
    for row in configurations:
        code = str(row.get("code", ""))
        if row.get("status") != status:
            continue
        if not code or code in status_rows:
            raise ConfigurationReportingScopeError(
                f"invalid or duplicate configuration code for status {status!r}"
            )
        status_rows[code] = row

    raw_configurations = spec.get("configurations")
    if not isinstance(raw_configurations, list) or not raw_configurations:
        raise ConfigurationReportingScopeError(
            "configurations must be a non-empty list"
        )

    configuration_sources: dict[str, str] = {}
    selected_rows: dict[str, Mapping[str, str]] = {}
    for item in raw_configurations:
        if not isinstance(item, dict):
            raise ConfigurationReportingScopeError(
                "configuration mappings must be objects"
            )
        code = item.get("configuration_code")
        source = item.get("source_code")
        if (
            not isinstance(code, str)
            or not code
            or not isinstance(source, str)
            or not source
            or code in configuration_sources
        ):
            raise ConfigurationReportingScopeError(
                "invalid or duplicate configuration/source mapping"
            )
        row = status_rows.get(code)
        if row is None:
            raise ConfigurationReportingScopeError(
                "selected configuration is missing or has a different status: "
                f"{code}"
            )
        configuration_sources[code] = source
        selected_rows[code] = row

    excluded_codes = tuple(sorted(set(status_rows) - set(configuration_sources)))
    return ConfigurationReportingScope(
        mode=EXPLICIT_SUBSET,
        status=status,
        configuration_sources=configuration_sources,
        selected_rows=selected_rows,
        status_rows=status_rows,
        excluded_codes=excluded_codes,
    )
